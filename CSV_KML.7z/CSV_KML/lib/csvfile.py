
import csv
import math


class Csvfile:

    #
    #   __init__ implementation is result of optimization (preporation of data and then its usage)
    #
    def __init__(self, filename):
        with open(filename, 'rU') as csvfile:
            streamreader = csv.reader(csvfile, delimiter=',', lineterminator="\n")
            self._rows_count = 0
            self._cols_count = 0
            row = 0
            for items in streamreader:
                self._rows_count += 1
                self._cols_count = max(len(items), self._cols_count)
                row += 1

        self._items = []
        for i in range(0, self._cols_count):
            self._items.append([])
            for j in range(0, self._rows_count):
                self._items[i].append(0)

        with open(filename, 'rU') as csvfile:
            streamreader = csv.reader(csvfile, delimiter=',', lineterminator="\n")
            row = 0
            for items in streamreader:
                for col in range(0, len(items)):
                    self._items[col][row] = items[col]
                row += 1

    def cols_count(self):
        return self._cols_count

    def rows_count(self):
        return self._rows_count

    def get(self, x, y):

        # index = str(x) + '_' + str(y)
        if x < len(self._items) and y < len(self._items[x]):
            return self._items[x][y]
        else:
            return None

    def is_number(self, x, y):
        if self.get(x, y) is None:
            return False

        try:
            float(self.get(x, y).replace(',', '.'))
            return True
        except ValueError:
            return False

    def get_number(self, x, y):
        if self.is_number(x, y):
            if ',' in self.get(x, y):
                return int(math.floor(float(self.get(x, y).replace(',', '.'))))  # trick from PHP script
            else:
                return float(self.get(x, y).replace(',', '.'))
        else:
            return None