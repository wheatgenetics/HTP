python converter.py -x1 -109.925805 -y1 27.382056 -x2 -109.924005 -y2 27.383251 -f input.csv
