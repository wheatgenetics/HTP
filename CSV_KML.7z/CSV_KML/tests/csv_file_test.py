
from os.path import dirname
from os.path import realpath
import sys
sys.path.insert(0, '.')
sys.path.insert(0, '..')

import unittest
from lib.csvfile import Csvfile

class TestCsvFile(unittest.TestCase):

    def setUp(self):
        # self.csv1 = Csvfile(dirname(realpath(__file__)) + '/res/1.csv')
        self.csv2 = Csvfile(dirname(realpath(__file__)) + '/res/2.csv')

    # def test_csv1(self):
    #     self.assertEqual(5, self.csv1.cols_count())
    #     self.assertEqual(3, self.csv1.rows_count())
    #     self.assertEqual('1', self.csv1.get(0, 0))
    #     self.assertEqual('50', self.csv1.get(1, 0))
    #     self.assertEqual('', self.csv1.get(0, 1))
    #     self.assertEqual(True, self.csv1.is_number(1, 0))
    #     self.assertEqual(False, self.csv1.is_number(0, 1))

    def test_csv2(self):
        self.assertEqual(54, self.csv2.cols_count())
        self.assertEqual(68, self.csv2.rows_count())

        self.assertEqual('0.7', self.csv2.get(1, 0))

        self.assertEqual(True, self.csv2.is_number(5, 0))
        self.assertEqual(0.7, self.csv2.get_number(5, 0))